const http = require('http');
var ServerManger = require("./dist/ServerManager").ServerManager;
var EventHandle = require("./dist/Dispose/RemoteEvent/EventHandle").EventHandle;
var LogHandle = require("./dist/Dispose/LogHandle").LogHandle;
var ComputerHandle = require("./dist/Dispose/ComputerHandle").ComputerHandle;
var ErrorLog = require("./dist/Dispose/ErrorLog").ErrorLog;
var logError = require("./dist/Dispose/ErrorLog").logError;
var StructureHanle = require("./dist/Dispose/StructureHanle").StructureHanle;

var server = http.createServer(function (req, res) { }).listen(9674, () => {
    //console.log("9674 start");
    try {
        var Manager = new ServerManger()
        Manager.addEvent(new LogHandle())
        Manager.addEvent(new EventHandle(Manager))
        Manager.addEvent(new ErrorLog(Manager))
        Manager.addEvent(new ComputerHandle(Manager))
        Manager.addEvent(new StructureHanle(Manager))
        Manager.start()
    } catch (error) {
        logError(error);
    }
});
server.on("error", () => { })
