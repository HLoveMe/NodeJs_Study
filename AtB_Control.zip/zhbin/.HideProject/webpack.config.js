const path = require('path');
// const { CleanWebpackPlugin } = require('clean-webpack-plugin');
module.exports = {
  mode: 'development',
  entry: path.join(__dirname,'index.js'),
  watch: false,
  output: {
    path: path.join(__dirname, "soure_dist"),
    filename: "index.js",
    chunkFilename: '[name].[hash].js'
  },
  module: {
    rules: [
      {
        test: /(\.jsx|\.js)$/,
        use: {
          loader: "babel-loader",
          options: {
            presets: [
              ['@babel/preset-env', {
                useBuiltIns: "usage",
                "corejs": 2
              }],
              ["@babel/preset-react"],
            ],
            plugins: ['@babel/plugin-proposal-class-properties']
          }
          
        },
        exclude: /node_modules/
      }
    ]
  },
  resolve: {
    extensions: ['.json', '.js', '.jsx']
  },
  devtool: 'eval-source-map',
  devServer: {
    contentBase: path.join(__dirname, "dist"),
    compress: true,
    port: 7777,
    open: true,
    hot: true,
  },
  plugins: [
    // new HtmlWebpackPlugin({
    //   filename: "index.html",
    //   template: path.join(__dirname, "index.html")
    // }),
    // new CleanWebpackPlugin()
  ]
};