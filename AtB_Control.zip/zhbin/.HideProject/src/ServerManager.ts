
import { IoConnect } from "./Connect";
import { Dispose } from "./Dispose/Dispose";
var shelljs = require("shelljs");
import { LOG } from "./Util/Log";
declare class EventR {
    data: string;
    type: string;
    dispose:string;
}
export enum ConnectStatus {
    noConnect = 0,
    Connecting = 1,
    Close = 2,
    Connect = 3
}

export class ServerManager {
    TAG: string = "ServerManager: "
    /**
     * 1未连接
     * 0 激活
     * -1断开 
     */
    status = ConnectStatus.noConnect;
    /**
     * 接受到事件  处理函数集合
     * {type:[calls]}
     */
    events: { [key: string]: Dispose[] } = {};
    /***
     * 连接状态变化函数
     */
    statusChangeListener = null;
    /***
     * 连接
     */
    websocket: IoConnect;

    options: { [key: string]: string } = {}
    constructor(ops) {
        this.options = ops || {
            url: "ws://119.29.16.140:7789"
        }
    }
    /***
    * log
    */
    log = (result: any) => {
        let handles = this.events["*"];
        handles && handles.map((item: Dispose) => {
            item.dispose(result)
        })
    }

    /**
     * 连接状态
     */
    _connect = () => {
        this.status = ConnectStatus.Connect;
        this.count = 0;
        LOG(this.TAG, "连接成功")
    }
    _isClearAll = (event: EventR) => {
        if (event.type == "clear-all") {
            let keys = Object.keys(this.events);
            for (let index = 0; index < keys.length; index++) {
                let handles = this.events[keys[index]];
                handles && handles.map((item: Dispose) => {
                    item.clear(event.data)
                })
            }
            return false;
        }
        return true;
    }
    _event = (event: EventR) => {
        try {
            let data = event.data;
            let result = JSON.parse(data);
            this.log(result);
            if (result.type && result.data && this._isClearAll(event)) {
                let handles = this.events[result.type];
                handles && handles.map((item: Dispose) => {
                    if (result.dispose) {
                        let dispose = item[result.dispose];
                        dispose.bind(item)(result.data);
                    }
                })
            }
        } catch (error) {
            console.log(error)
        }

    }
    _disconnect = () => {
        this.status = ConnectStatus.Close;
        this.websocket.clear()
        this.websocket = null;
        LOG(this.TAG, "websocket 断开")
        this.count == 0 && this._restart();
    };

    /**
     * 增加事件处理
     */
    addEvent = (dispose: Dispose) => {
        let type = dispose.type;
        let evs = this.events[type]
        if (evs == null) {
            evs = [dispose]
            this.events[type] = evs;
        } else {
            evs.push(dispose)
        }
    }
    /**
     * 移除事件
     */
    removeEvent = () => { }
    start() {
        this.websocket = new IoConnect(this.options.url, this._connect, this._event, this._disconnect)
        this.websocket.start();
    }
    /***
     * 发送消息
     */
    send = (data: any) => {
        this.websocket && this.websocket.send(data);
    }
    /***
     * 重新连接
     */
    count = 0;
    exit() {
        LOG(this.TAG, "不在重新连接");
        shelljs.exec(`kill -9 ${process.pid}`)
    }
    _restart(max = 10) {
        if (this.count > max) return this.exit();
        if (this.websocket != null) return;
        this.count = this.count + 1;
        LOG(this.TAG, "重新连接")
        this.start();
        setTimeout(() => this._restart(), 1000 * Math.pow(2, this.count + 1))
    }

}