const os = require('os');

var dealTime = (_seconds: number) => {
    var seconds = seconds | 0;
    var day = (seconds / (3600 * 24)) | 0;
    var hours = ((seconds - day * 3600) / 3600) | 0;
    var minutes = ((seconds - day * 3600 * 24 - hours * 3600) / 60) | 0;
    var second = seconds % 60;
    let _day = "";
    let _hours = "";
    let _minutes = "";
    let _second = "";
    (day < 10) && (_day = '0' + day);
    (hours < 10) && (_hours = '0' + hours);
    (minutes < 10) && (_minutes = '0' + minutes);
    (second < 10) && (_second = '0' + second);
    return [_day, _hours, _minutes, _second].join(':');
};

var dealMem = (mem) => {
    var G = 0,
        M = 0,
        KB = 0;
    var _G = "",
        _M = "",
        _KB = "";
    (mem > (1 << 30)) && (_G = (mem / (1 << 30)).toFixed(2));
    (mem > (1 << 20)) && (mem < (1 << 30)) && (_M = (mem / (1 << 20)).toFixed(2));
    (mem > (1 << 10)) && (mem > (1 << 20)) && (_KB = (mem / (1 << 10)).toFixed(2));
    return G > 0 ? _G + 'G' : M > 0 ? _M + 'M' : KB > 0 ? _KB + 'KB' : mem + 'B';
};
export class OSInfo {
    arch: any;
    kernel: any;
    pf: any;
    uptime: any;
    hn: any;
    hdir: any;
    mem: any;
    cpus: any[];
    nets: any[];
}
export function getComputerInfo(): OSInfo {
    let info = new OSInfo();
    //cpu架构
    const arch = os.arch();
    info.arch = arch;


    //操作系统内核
    const kernel = os.type();
    info.kernel = kernel;

    //操作系统平台
    const pf = os.platform();
    info.pf = pf;

    //系统开机时间
    const uptime = os.uptime();
    info.uptime == dealTime(uptime);

    //主机名
    const hn = os.hostname();
    info.hn = hn;

    //主目录
    const hdir = os.homedir();
    info.hdir = hdir;


    //内存
    const totalMem = os.totalmem();
    const freeMem = os.freemem();
    info.mem = { totalMem: dealMem(totalMem), freeMem: dealMem(freeMem) }

    //cpu
    const cpus = os.cpus();
    info.cpus = [];
    cpus.forEach((cpu, idx, arr) => {
        var times = cpu.times;
        info.cpus.push({
            idx,
            model: `${cpu.model}`,
            speed: `${cpu.speed}MHz`,
            user: `${((1 - times.idle / (times.idle + times.user + times.nice + times.sys + times.irq)) * 100).toFixed(2)}%`
        })
    });


    //网卡
    const networksObj = os.networkInterfaces();
    info.nets = [];
    for (let nw in networksObj) {
        let objArr = networksObj[nw];
        objArr.forEach((obj, idx, arr) => {
            info.nets.push({
                address: `${obj.address}`,
                netmask: `${obj.netmask}`,
                mac: `${obj.mac}`,
                family: `${obj.family}`,
            })
        });
    }
    return info;
}