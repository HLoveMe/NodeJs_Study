
import * as WebSocket from "ws";
import { LOG } from "./Util/Log";
export class IoConnect {
    TAG: string = "IoConnect: "
    io: WebSocket = null;
    url: string = null;
    connect: (this: WebSocket) => void = null;
    event: (event: { data: any; type: string; target: WebSocket }) => void = null;
    disconnect: (event: {
        wasClean: boolean; code: number;
        reason: string; target: WebSocket
    }) => void = null;
    constructor(url, connect, event, disconnect) {
        this.connect = connect;
        this.event = event;
        this.disconnect = disconnect;
        this.url = url;
    }
    start = () => {
        try {
            this.io = new WebSocket(this.url)
            this.io.addEventListener("open", this.connect)
            this.io.addEventListener("close", this.disconnect)
            this.io.addEventListener("message", this.event)
            this.io.addEventListener("error",(error)=>{
                LOG(this.TAG,error.message)    
            })
        } catch (error) {
            LOG(this.TAG,"new WebSocket(this.url) error")
        }
    }
    clear = () => {
        this.io.close();
        this.io = null;
    }
    send = (data: any) => {
        let _data = typeof data == "string" ? data : JSON.stringify(data);
        LOG(this.TAG, "发送执行结果到ws", _data)
        this.io && this.io.send(_data);
    }
}