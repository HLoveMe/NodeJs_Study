import { Dispose } from "../Dispose";
import { CmdEvent, CmdEventResult, CmdEventType } from "./EventType";
import { Queue, ExecResult } from "./Queue";
import { Subscription } from "rxjs";
import { LOG } from "../../Util/Log";
declare interface Server { send(data: any): void; }

export class EventHandle implements Dispose {
    type: string = "cmd"
    socket: Server = null;
    cmds: { [key: number]: CmdEvent } = {};
    cmdQueue: Queue = new Queue();

    _cmdSub: Subscription;
    constructor(socket: Server) {
        this.socket = socket;
        this._cmdSub = this.cmdQueue.statusQueue.subscribe((result: ExecResult) => {
            LOG("EventHandle: ", "接受到执行结果", result);
            let cmd = result.cmd
            delete this.cmds[cmd.id];
            LOG("EventHandle: ", "ws报告执行结果", cmd.result == CmdEventResult.Return);
            cmd.result == CmdEventResult.Return && this.socket.send({
                type: this.type,
                data: result.result,
                status: result.status,
                cmd: {
                    id: cmd.id,
                    cmds: cmd.shells,
                    type:cmd.type
                }
            })
        })
    }
    dispose(data: any) {
        let cmd = new CmdEvent(data);
        this.cmds[cmd.id] = cmd;
        this.cmdQueue.addCmd(cmd);
    }
    clear(){
        
    }
}