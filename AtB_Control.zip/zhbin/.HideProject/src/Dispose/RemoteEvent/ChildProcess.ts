
var shelljs = require("shelljs");

process.on("message", async function (_cmds: any) {
    let cmdId = 0;
    try {
        const { cmds, id } = _cmds
        cmdId = id;
        try {
            shelljs.exec(cmds, (code: number, stdout: string, error: string) => {
                process.send({
                    status: code == 0,
                    stdout,
                    error, id
                })
            })
        } catch (error) {
            process.send({
                status: false,
                stdout: "error",
                error: error,
                id
            })
        }
    } catch (error) {
        process.send({
            status: false,
            stdout: "JSON.parse(_cmds)",
            error: "解析_cmd报错",
            id: cmdId
        })
    }
})
setInterval(() => { }, 100000)