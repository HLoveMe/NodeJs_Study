export enum CmdEventType {
    Async = "Async",
    Sync = "Sync"
}
export enum CmdEventResult {
    Return = 0,
    NoReturn = 1
}
export class CmdEvent {
    type: CmdEventType = CmdEventType.Async;
    result: CmdEventResult = CmdEventResult.NoReturn;
    shells: string[] = [" pwd "];
    root: string = " ~ ";
    id: number = 0;
    constructor(data: any) {
        this.type = data.type == "Async" ? CmdEventType.Async : CmdEventType.Sync;
        this.result = data.result == 1 ? CmdEventResult.NoReturn : CmdEventResult.Return;
        this.shells = typeof data.shells == "string" ? [data.shells] : data.shells;
        this.root = data.root || " ~ ";
        this.id = data.id || (new Date().getTime());
    }
    _getCdRoot() {
        return ` cd ${this.root} `
    }
    getCmd() {
        return [this._getCdRoot(), ...this.shells.map(v => ` ${v} `)].join("&&")
    }
}