
import { CmdEvent, CmdEventType } from "./EventType";
import { Subscription, Subject, Observable } from "rxjs";
import * as Process from "child_process";
import { LOG } from "../../Util/Log";
var path = require("path");
export class ExecResult {
    status: boolean;
    cmd: CmdEvent;
    result: string;
    constructor(status: boolean, cmd: CmdEvent, result: string) {
        this.status = status;
        this.cmd = cmd;
        this.result = result;
    }
}
export class Queue {
    /***
     * 所有需要执行的任务
     */
    cmds: CmdEvent[] = [];
    child: Process.ChildProcess = null;
    /***
     * 对外表现状态
     */
    statusQueue: Subject<ExecResult> = new Subject();
    /***
     * 命令执行出发前
     */
    _signQueue: Subject<any> = new Subject<any>();
    _siSubscription: Subscription;
    /**
     * 记录当前同步任务
     */
    _currentEvent = null;
    /***
     * 执行中的任务
     */
    _execCmdsIng: { [key: number]: CmdEvent } = {}
    constructor() {
        let pathLink = path.join(__dirname, "ChildProcess.js")
        this.child = Process.fork(pathLink);
        this.child.on("message", (result: any) => {
            LOG("Queue: ", "接受到任务执行结果===>Ing",result);
            let cmd: CmdEvent = null;
            try {
                const { status, stdout, error, id } = result;
                cmd = this._execCmdsIng[id];
                delete this._execCmdsIng[id];
                let exResult = new ExecResult(status, cmd, status ? stdout : error);
                LOG("Queue: ", "报告任务执行结果");
                this.statusQueue.next(exResult)
            } catch (error) {
                LOG("Queue: ", "接受到任务执行结果===>Error",error);
            } finally {
                /**
                 * 异步 同步 执行完成
                 * 
                 * 开启下一个任务
                 */
                this._execNext(cmd, true);
            }
        })
        this._siSubscription = this._signQueue
            .filter(() => {
                // if () return false;
                // let cmd = this.cmds[this.cmds.length - 1];
                // if (cmd.type == CmdEventType.Async) return true;
                return this._currentEvent == null && this.cmds.length >= 1;
            })
            .map<any, CmdEvent>(() => {
                let cmd = this.cmds.pop();
                cmd.type == CmdEventType.Sync && (this._currentEvent = cmd);
                this._execCmdsIng[cmd.id] = cmd;
                return cmd;
            })
            .subscribe((event: CmdEvent) => {
                LOG("Queue: ", "开始执行下一个任务");
                //执行命令
                this.child.send({
                    cmds: event.getCmd(),
                    id: event.id
                })
                //执行下一个命令
                this._execNext(event, false)
            })
    }
    /***
     * 执行下一个命令
     */
    _execNext = (event?: CmdEvent, execEd: boolean = false) => {

        if (execEd == false) {
            if (event.type == CmdEventType.Async) {
                this._signQueue.next(1)
            }
        } else {
            this._currentEvent = null;
            event ? (event.type == CmdEventType.Sync && this._signQueue.next(1)) : this._signQueue.next(1);
        }
    }
    addCmd(cmd: CmdEvent) {
        this.cmds.push(cmd);
        this._signQueue.next(1);
    }
    /**
     * 关闭
     */
    close() {
        this._siSubscription && this._siSubscription.unsubscribe();
    }
}