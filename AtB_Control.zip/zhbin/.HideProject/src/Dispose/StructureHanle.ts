import { Dispose } from "./Dispose";
declare interface Server { send(data: any): void; }
var path = require("path");
var fs = require("fs")

function walk(dir, depth = 5) {
    var children = []
    if (depth == 0) return [dir]
    fs.readdirSync(dir).forEach(function (filename) {
        var _path = path.join(dir, filename);
        var stat = fs.statSync(_path)
        if (stat && stat.isDirectory()) {
            children = children.concat(walk(_path, depth - 1))
        }
        else {
            children.push(_path)
        }
    })
    return children
}

export class StructureHanle implements Dispose {
    type: string = "structure"
    TAG = "StructureHanle"
    socket: Server = null;
    constructor(socket: Server) {
        this.socket = socket;
    }
    dispose(data: any) {
        try {
            let dir = data.path;
            let depth = typeof data.depth == "number" ? data.depth : 1;
            depth = Math.min(depth, 5)
            this.socket && this.socket.send({
                type: this.type,
                data: walk(dir, depth)
            })
        } catch (error) {
            this.socket && this.socket.send({
                type: "structure",
                error: error.message,
                data
            })
        }
    }
    clear(){}
}