
import { Dispose } from "./Dispose";

export class FileHandle implements Dispose {
    type: string = "file"
    dispose(data: any) {
        console.log(new Date(), data)
    }
    clear(){}
}