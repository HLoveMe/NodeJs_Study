import { Dispose } from "./Dispose";
var path = require("path");
var fs = require("fs");

declare interface Server { send(data: any): void; }
export const ErrorLogPath = path.join(__dirname, "../", "now.log")

export const logError = (error: Error) => {
    fs.writeFileSync(ErrorLogPath, JSON.stringify(error));
}

export class ErrorLog implements Dispose {
    type: string = "errorLog"
    socket: Server = null;
    constructor(socket: Server) {
        this.socket = socket;
    }
    dispose() {
        try {
            if (fs.existsSync(ErrorLogPath)) {
                let data = fs.readFileSync(ErrorLogPath, "utf-8")
                this.socket.send({
                    type:this.type,
                    data
                });
                fs.unlinkSync(ErrorLogPath);
            }
        } catch (error) {

        }
    }
    clear(){}
}

