import { Dispose } from "./Dispose";
import { getComputerInfo } from "../Util/OSInfo";


declare interface Server { send(data: any): void; }

export class ComputerHandle implements Dispose {
    type: string = "info"
    socket: Server = null;
    timer: NodeJS.Timeout;
    constructor(socket: Server) {
        this.socket = socket;
    }
    dispose(data = { timer: 30000 }) {
        this.timer && clearInterval(this.timer);
        this.socket.send(this._getInfo());
        this.timer = setInterval(() => {
            this.socket.send(this._getInfo());
        }, data.timer)
    }
    _getInfo = () => {
        return {
            type: this.type,
            data: getComputerInfo()
        }
    }
    clear(){
        this.timer && clearInterval(this.timer);
    }
}