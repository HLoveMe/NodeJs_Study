import { Dispose } from "./Dispose";

//仅仅做接受任务的打印输出
export class LogHandle implements Dispose {
    type: string = "*"
    TAG = "LogHandle"
    dispose(data: any) {
        console.log(` ${this.TAG}:`, data)
    }
    clear(){}
}