

export interface Dispose {
    type: string;
    dispose(data: any): void;
    clear(data: any):void; 
}