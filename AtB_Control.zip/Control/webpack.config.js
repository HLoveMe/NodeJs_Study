const path = require('path');
var HtmlWebpackPlugin = require('html-webpack-plugin');
const { CleanWebpackPlugin } = require('clean-webpack-plugin');
module.exports = {
  mode: 'development',
  entry: path.join(__dirname, "src", 'index'),
  watch: false,
  output: {
    path: path.join(__dirname, "dist"),
    filename: "bundle.[hash].js",
    chunkFilename: '[name].[hash].js'
  },
  module: {
    rules: [
      {
        test: /(\.jsx|\.js)$/,
        use: {
          loader: "babel-loader",
          options: {
            presets: [
              ['@babel/preset-env', {
                useBuiltIns: "usage",
                "corejs": 2
              }],
              ["@babel/preset-react"],
            ],
            plugins: ['@babel/plugin-proposal-class-properties']
          }
          
        },
        exclude: /node_modules/
      }, {
        test: /\.(png|svg|jpg|gif|jpeg)$/,
        use: {
          loader: "url-loader",
          options: {
            limit: 1024 * 20,
            outputPath: "images/",
            name: "[name]_[hash].[ext]"
          }
        }
      }, {
        test: /\.css$/,
        use: [
          'style-loader',
          {
            loader: 'css-loader',
            options: {
              importLoaders: 1,
              modules: true
            }
          },
          {
            loader: "postcss-loader",
            options: {
              plugins: [
                require("autoprefixer")
              ]
            }
          }
        ]
      }, {
        test: /\.scss$/,
        use: [
          "style-loader",
          {
            loader: "css-loader",
            options: {
              importLoaders: 3,
              modules: true
            }
          },
          {
            loader: "postcss-loader",
            options: {
              plugins: [
                require("autoprefixer")
              ]
            }
          },
          {
            loader: "sass-loader" // 将 Sass 编译成 CSS
          },{
            loader: 'sass-resources-loader',
            options: {
              resources: ['./src/public/styles/mixins/*.scss', './src/public/styles/variables/variable.scss']
            },
          }]
      }
    ]
  },
  resolve: {
    extensions: ['.json', '.js', '.jsx']
  },
  devtool: 'eval-source-map',
  devServer: {
    contentBase: path.join(__dirname, "dist"),
    compress: true,
    port: 7777,
    open: true,
    hot: true,
  },
  plugins: [
    new HtmlWebpackPlugin({
      filename: "index.html",
      template: path.join(__dirname, "index.html")
    }),
    new CleanWebpackPlugin()
  ]
};