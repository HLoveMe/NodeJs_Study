import React, { Component, PureComponent } from "react";
import ReactDOM from "react-dom";
import { Home } from "./Home";
class App extends Component {
    constructor(props) {
        super(props)

    }
    render() {
        return (
            <Home></Home>
            // <div>asas</div>
        )
    }
}

ReactDOM.render(<App />, document.getElementById("root"))