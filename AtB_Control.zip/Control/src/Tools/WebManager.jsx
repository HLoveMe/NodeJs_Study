import { Subject } from "rxjs";

export class Result {
    status = -1;//-1 close ;0 connect ;1 message
    error = null;
    data = null;
    constructor(status, data, error) {
        this.data = data;
        this.status = status;
        this.error = error;
    }
}

class _WebManager {
    webSocket = null;
    webQueue = new Subject();
    constructor() { }
    connect(ip = "119.29.16.140", port = 7788) {
        //ws://119.29.16.140:7789
        this.webSocket = new WebSocket(`ws://${ip}:${port}`)
        this.webSocket.onopen = this.onopen;

        this.webSocket.onmessage = this.onmessage;

        this.webSocket.onclose = this.onclose;
    }
    onopen = () => {
        this.webQueue.next(new Result(0, null, null))
    }
    onmessage = ({ data }) => {
        this.webQueue.next(new Result(1, data, null))
    }
    onclose = (ev) => {
        this.webQueue.next(new Result(-1, null, ev))
    }
    send(data){
        this.webSocket && this.webSocket.send(JSON.stringify(data))
    }
}

export const WebManager = new _WebManager();