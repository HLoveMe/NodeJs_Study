

export const EventType = {
    file: "file", //获取文件
    cmd: "cmd",//cmd
    errorLog: "errorLog",//获取日志
    info: "info",//得到电脑信息
    structure: "structure",//得到目录结构
    websocket: "websocket", //仅仅提示信息
}
export const CmdEventType = {
    Async: "Async",
    Sync: "Sync"
}
export const CmdEventResult = {
    Return: 0,
    NoReturn: 1
}
// export declare interface Structure {
//     depth: number;
//     path: number
// }
// export declare interface Cmd {
//     type: string;//Async Sync 【CmdEventType】
//     result: number;//1无结果  0有结果 【CmdEventResult】
//     shells: string | string[];
//     root: string
// }
export function CmdData(shells, type = CmdEventType.Sync, result = CmdEventResult.Return, root = "~") {
    return {
        shells,
        root,
        type,
        result
    }
}
export class RemoveEvent {
    type = "";
    data = null;
    dispose = "dispose";
    constructor(type, data) {
        this.type = type;
        this.data = data;
    }
    getCmd() {
        return {
            type: this.type,
            data: this.data,
            dispose: this.dispose
        }
    }
    getUnCmd() {
        return {
            type: this.type,
            data: {},
            dispose: "clear"
        }
    }
}
export function CreateCmdEvent(data) {
    return new RemoveEvent(EventType.cmd, data)
}
export function CreateErrorEvent() {
    return new RemoveEvent(EventType.errorLog, {})
}

export function CreateStructureEvent(data) {
    return new RemoveEvent(EventType.structure, data)
}

export function CreateInfoEvent() {
    return new RemoveEvent(EventType.info, { timer: 10000 })
}

export function CreateFileEvent() {
    return new RemoveEvent(EventType.file, {})
}