import React, { Component, PureComponent } from "react";
import HeaderStyle from "../scss/header.scss";

export class Header extends Component {
    settings = [
        {
            type: "Sync",
            titles: ["同步命令", "异步命令"]
        }, {
            type: "Return",
            titles: ["有返回值", "无返回值"]
        }
    ]
    constructor(props) {
        super(props)
        this.state = {
            Sync: true,
            Return: true,
        }
    }
    componentDidMount() {
        this.sendStatus()
    }
    _onPress = (type) => {
        this.setState((state) => {
            return {
                [type]: !state[type]
            }
        }, () => this.sendStatus());
    }
    sendStatus() {
        this.props.onStatus && this.props.onStatus(this.state);
    }
    _onKeyDown = (event) => {
        if (event.keyCode == 13) {
            this.props.changeRoot(this.refs.rootInput.value);
            event.stopPropagation()
        }
    }
    render() {
        return (
            <div className={HeaderStyle.header}>
                {
                    this.settings.map(({ type, titles }) => {
                        return (
                            <div key={type} onClick={() => this._onPress(type)}>
                                <span>{titles[this.state[type] ? 0 : 1]}</span>
                            </div>
                        )
                    })
                }
                <div>
                    当前目录 : {this.props.root}
                    <div></div>
                    <br />
                    <input ref="rootInput"  onKeyDown={this._onKeyDown} ></input>
                </div>
            </div>
        )
    }
}