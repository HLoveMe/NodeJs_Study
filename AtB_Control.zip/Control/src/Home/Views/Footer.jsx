import React, { Component, PureComponent } from "react";
import FooterStyle from "../scss/footer.scss";
export class Footer extends Component {
    constructor(props) {
        super(props)

    }
    render() {
        return (
            <div className={FooterStyle.footer}>
                ASASAFooterStyle
            </div>
        )
    }
}