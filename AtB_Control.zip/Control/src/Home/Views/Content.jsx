import React, { Component, PureComponent } from "react";
import ContentStyle from "../scss/content.scss";
import { CmdData, RemoveEvent, CreateCmdEvent } from "../../Tools/RemoteEvent";

class DIV extends Component {
    render() {
        return (<div>
            {this.props.text}
        </div>)
    }
}
export class Content extends Component {
    constructor(props) {
        super(props)
        this.state = {
            info: this._infoif(null),
            inputEdit: this.props.inputEdit,
            cmds: []
        }
    }
    componentDidMount() {
    }
    UNSAFE_componentWillReceiveProps(nextP) {
        if (nextP.info != this.props.info) {
            this.setState({
                info: this._infoif(nextP.info)
            });
        }
        if (nextP.inputEdit != this.props.inputEdit) {
            this.setState({
                inputEdit: nextP.inputEdit
            });
        }
    }
    _infoif(info) {
        return info
    }
    _onKeyDown = (event) => {
        if (event.keyCode == 13) {
            this.showCmdResult(`${this.props.prefix} : ${this.refs.cmdInput.value}`)
            this.props.returnPress(this.refs.cmdInput.value)
            event.stopPropagation()
        }
    }
    clearHistory = () => {
        this.setState({ cmds: [] });
    }
    //清空输入
    clearInput = () => {
        this.refs.cmdInput.value = "";
    }
    //显示一次结果 | cmd
    showCmdResult = (data = "~") => {
        this.setState({
            cmds: [...this.state.cmds,
            // React.createElement("div", { text: data, key: `1-${this.state.cmds.length}` })
            <DIV text={data} key={`1-${this.state.cmds.length}`}></DIV>
            ]
        },()=>{
            setTimeout(()=>{
                this.refs.cmds.scrollTop = this.refs.cmds.scrollHeight;
            },250)
        })
    }
    render() {
        return (
            <div className={ContentStyle.content}>
                <div className={ContentStyle.cmd} id="add-content">
                    <div ref="cmds" className={ContentStyle.cmds}>
                        {this.state.cmds}
                    </div>
                    <input disabled={this.state.inputEdit} ref="cmdInput" className={ContentStyle.cmd_input} onKeyDown={this._onKeyDown}>

                    </input>
                </div>
                <div className={[ContentStyle.info]}>
                    <div className={ContentStyle.info_content}>
                        {
                            JSON.stringify(this.state.info, null, 2)
                        }
                    </div>
                </div>
            </div>
        )
    }
}