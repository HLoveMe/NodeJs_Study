import React, { Component, PureComponent } from "react";
import MainStyle from "./scss/mian.scss";
import { Header } from "./Views/Header";
import { Content } from "./Views/Content";
import { Footer } from "./Views/Footer";
import { WebManager } from "../Tools/WebManager";
import { CreateInfoEvent, CreateErrorEvent, CmdData, CreateCmdEvent, EventType, CmdEventType, CmdEventResult } from "../Tools/RemoteEvent";

export class Home extends Component {
    constructor(props) {
        super(props)
        this.state = {
            Sync: true,
            Return: true,
            info: {},//电脑信息
            inputEdit: true,//是否可以输入命令
            root: "~",
            rootHistory: ["~"],
            prefix: "~"
        }
    }
    _handleEventResult = (resData) => {
        let data = typeof resData == "string" ? JSON.parse(resData) : resData
        switch (data.type) {
            case EventType.info:
                this.setState({ info: data }, this._setprefix);
                break;
            case EventType.structure:
                break;
            case EventType.cmd:
                console.log("===>", data);
                let result = data.data;
                this.refs.content.showCmdResult(result);
                break;
            case EventType.errorLog:
                break;
            case EventType.file:
                break;
        }
    }
    componentDidMount() {
        WebManager.connect();
        WebManager.webQueue.subscribe((result) => {
            try {
                let status = result.status;
                let error = result.error;
                let data = result.data;
                if (status == 0) {
                    this._sendInitCmd()
                } else if (status == 1) {
                    //得到指令结果
                    let resData = JSON.parse(data);
                    this._handleEventResult(resData);
                    this.setState({ inputEdit: true });
                }
                console.log("websocket接受 : ",result)
            } catch (error) {
                console.log("subscribe ===> ", error)
            }
            // console.log(data,error)
        })
    }
    _sendInitCmd() {
        [CreateInfoEvent(), CreateErrorEvent()].map((event) => {
            WebManager.send(event.getCmd())
        })
    }
    _onStatus = (state) => {
        this.setState({
            ...state
        });
    }
    _create = (cmdText) => {

        if (cmdText) {
            let _cmdText = cmdText.trim();
            if (_cmdText == "clear") {
                this.refs.content.clearHistory()
                return null;
            }

            return CmdData(
                cmdText,
                this.state.Sync ? CmdEventType.Sync : CmdEventType.Async,
                this.state.Return ? CmdEventResult.Return : CmdEventResult.NoReturn,
                this.state.root
            );
        }

    }
    _returnPress = (cmdText) => {
        let cmd = this._create(cmdText);
        if (cmd) {
            let reCmd = CreateCmdEvent(cmd);
            WebManager.send(reCmd.getCmd())
            this.refs.content.clearInput()
            if (cmd.type == CmdEventType.Sync) {
                //禁止输入
                this.setState((state) => {
                    return {
                        inputEdit: !state.inputEdit
                    }
                })
            }
        }
    }
    _setprefix = () => {
        this.setState({
            //rypMac:Linux yejia$ 
            prefix: `${this.state.info.data.hn} ${this.state.root} ${this.state.info.data.hdir}`
        });
    }
    _changeRoot = (root) => {
        this.setState({ root });
    }
    render() {
        return (
            <div className={[MainStyle.container]}>
                <Header root={this.state.root} onStatus={this._onStatus} changeRoot={this._changeRoot}></Header>
                <Content prefix={this.state.prefix} input={this.state.inputEdit} ref="content" info={this.state.info} returnPress={this._returnPress}></Content>
                <Footer></Footer>
            </div>
        )
    }
}