var WsManager = require("./dist/WsManager").WsManager
var ControlWs = require("./dist/ControlWs").ControlWs

function ItoY(i, message) {
    console.log(i,message)
    if (i) {
        Manager.send(message)//===>控制对象
    } else {
        Control.send(message)//返回结果
    }
}

let Manager = new WsManager();
let Control = new ControlWs();
Manager.messaheHandle = ItoY;
Control.messaheHandle = ItoY;
// 9999
Manager.start();
// 9998
Control.start();






/***
 *
 *
 *
 *
 *
 * 下达
 * 我 ---->9998 ----->9999------>A
 *
 * 结果
 * A----->9999---->9998---->我
 */