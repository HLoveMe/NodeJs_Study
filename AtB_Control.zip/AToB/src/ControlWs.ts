import * as WebSocket from "ws";
import { RemoveEvent, clearAllEvent } from "./RemoveEvent";

export class ControlWs {
    wss: WebSocket.Server = null;
    socket: WebSocket = null;
    port: number = 0;
    messaheHandle: Function = null;
    constructor(port: number = 9998) {
        this.port = port;
    }
    start() {
        this.wss = new WebSocket.Server({ port: this.port });
        this.wss.on("connection", this._connect);
        this.wss.on("error", this._close);
        this.wss.on("close", this._close);
    }
    _close = () => {
        this.messaheHandle && this.messaheHandle(true,clearAllEvent())
    }
    _connect = (socket: WebSocket) => {
        console.log("9998连接成功")
        this.socket = socket;
        socket.on('message', this._onMessage);
        this.socket.send(JSON.stringify({ type: "websoket", status: "connect success ....." }));
    }
    _onMessage = (message: any) => {
        try {
            message = JSON.parse(message);
            let cmd = new RemoveEvent(message.type, message.data)
            this.messaheHandle && this.messaheHandle(true, cmd)
        } catch (error) {
            console.log("ControlWs: ", "接受我的命令出错", error);
        }

    }
    send(message: any) {
        try {
            this.socket && this.socket.send(JSON.stringify(message))
        } catch (error) {
            console.log("ControlWs: ", "执行结果发送给我 报错", error);
        }

    }
}