import * as WebSocket from "ws";
import { RemoveEvent, CreateInfoEvent, CreateErrorEvent } from "./RemoveEvent";

export class WsManager {
    wss: WebSocket.Server = null;
    socket: WebSocket = null;
    port: number = 0;
    // initCmds: RemoveEvent[] = [CreateInfoEvent(), CreateErrorEvent()]

    messaheHandle: Function = null;
    constructor(port: number = 9999) {
        this.port = port;
    }
    start() {
        this.wss = new WebSocket.Server({ port: this.port });
        this.wss.on("connection", this._connect);
    }
    _connect = (socket: WebSocket) => {
        this.socket = socket;
        socket.on('message', this._onMessage);
        // this.initCmds.map((cmd: RemoveEvent) => {
        //     this.send(cmd)
        // })
        console.log("WsManager: ","连接成功")
    }
    _onMessage = (message: any) => {
        try {
            this.messaheHandle && this.messaheHandle(false, message)
        } catch (error) {
            console.log("WsManager: ", "接受到执行结果", error);
        }

    }
    send(cmd: RemoveEvent) {
        try {
            this.socket && this.socket.send(JSON.stringify(cmd.getCmd()))
        } catch (error) {
            console.log("WsManager: ", "把命令下发到指定机器报错", error);
        }
    }
}