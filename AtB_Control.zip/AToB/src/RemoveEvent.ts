
export enum EventType {
    file = "file", //获取文件
    cmd = "cmd",//cmd
    errorLog = "errorLog",//获取日志
    info = "info",//得到电脑信息
    structure = "structure",//得到目录结构
    websocket = "websocket", //仅仅提示信息
    clearAll = "clear-all"
}
export enum CmdEventType {
    Async = "Async",
    Sync = "Sync"
}
export enum CmdEventResult {
    Return = 0,
    NoReturn = 1
}
export declare interface Structure {
    depth: number;
    path: number
}
export declare interface Cmd {
    type: string;//Async Sync 【CmdEventType】
    result: number;//1无结果  0有结果 【CmdEventResult】
    shells: string | string[];
    root: string
}
export class RemoveEvent {
    type = "";
    data = null;
    dispose = "dispose";
    constructor(type, data) {
        this.type = type;
        this.data = data;
    }
    getCmd() {
        return {
            type: this.type,
            data: this.data,
            dispose: this.dispose
        }
    }
    getUnCmd() {
        return {
            type: this.type,
            data: {},
            dispose: "clear"
        }
    }
}
export function CreateCmdEvent(data: Cmd): RemoveEvent {
    return new RemoveEvent(EventType.cmd, data)
}
export function CreateErrorEvent(): RemoveEvent {
    return new RemoveEvent(EventType.errorLog, {})
}

export function CreateStructureEvent(data: Structure): RemoveEvent {
    return new RemoveEvent(EventType.structure, data)
}

export function CreateInfoEvent(): RemoveEvent {
    return new RemoveEvent(EventType.info, { timer: 10000 })
}

export function CreateFileEvent(): RemoveEvent {
    return new RemoveEvent(EventType.file, {})
}

export function clearAllEvent(): RemoveEvent {
    return new RemoveEvent(EventType.clearAll, {});
}